package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Emp;

import com.cg.appl.exceptions.EmpExceptions;


public interface EmpServices {
	 Emp getEmpDetails(int empId)throws EmpExceptions;
	 List<Emp>getAllEmp()throws EmpExceptions;
	 Emp addEmpeDetails(Emp emp )throws EmpExceptions;
	 Emp updateEmp(Emp emp)throws EmpExceptions; 
	 boolean deleteEmp(int empNo)throws EmpExceptions;
}
