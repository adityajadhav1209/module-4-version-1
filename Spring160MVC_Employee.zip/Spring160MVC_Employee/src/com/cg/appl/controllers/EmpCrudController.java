package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.services.EmpServices;


@Controller
public class EmpCrudController {

	
	private EmpServices services;
	
	
	@PostConstruct
	public void initialize(){
		
	
	}
	
	
	@Resource(name="empService")
	public void setTraineeServices(EmpServices services){
		
		
		this.services=services;
	}
	
	
	
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		
		ModelAndView model = new ModelAndView("welcome");
		return model;
		
	}
	
	
	
	@RequestMapping("/enterEmpNo.do")
	public ModelAndView enterEmpNo(){
		System.out.println("In controlling method");
		ModelAndView model = new ModelAndView("enterEmpNo");
		return model;
		
	}
	
	@RequestMapping("/getEmpDetails.do")
	public ModelAndView getEmpDetails(@RequestParam("empNo") int empNo){
		
		System.out.println("In Controlling method:" +empNo);
		
		ModelAndView model=null;
		try {
			Emp emp = services.getEmpDetails(empNo);
		
			if(emp==null){
				model = new ModelAndView("enterEmpNo");
				model.addObject("errorMsg", "empNo does not exist");
				
				
			}
			else{
				
				model = new ModelAndView("empDetails");
				model.addObject("empDetails",emp);
				}
			
		} catch (EmpExceptions e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
		
	}
	
	@RequestMapping("/listAllEmps.do")
	public ModelAndView listAllEmps(){
    ModelAndView model=null;	
	try {
		List<Emp> emp = services.getAllEmp();
		model = new ModelAndView("listAllEmps");
		model.addObject("empDetails", emp);
	} catch (EmpExceptions e) {
		model = new ModelAndView("error");
		model.addObject("errMsg", e.getMessage());
	}
	
	return model;
		
	}
	

	@RequestMapping("/getUpdateForm.do")
	public ModelAndView getentryForm(@RequestParam("id") int empNo){
		 ModelAndView model=null;
		
		try {
			Emp emp = services.getEmpDetails(empNo);
			
			 model = new ModelAndView("update");
			model.addObject("emp", emp);
		} catch (EmpExceptions e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		
		return model;
		
	}
	@RequestMapping("/submitUpdateForm.do")
	public String submitUpdateForm(@ModelAttribute @Valid Emp emp, BindingResult result,Model model){
	  
	   if(result.hasErrors()){
		   
		  model.addAttribute("emp",emp);
		  return "update";
		   
	   }
		try {
			Emp empResponse =	services.updateEmp(emp);
			model.addAttribute("empDetails", empResponse);
			return "successUpdate";
		} catch (EmpExceptions e) {
			model.addAttribute("errMsg", "Updation failed:"+e.getMessage());
			return "error";
			
		}
		
	}
	
	
	
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getentryForm(){
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("emp", new Emp());
		
		return model;
		
	}
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Emp emp, BindingResult result){
	   ModelAndView model = new ModelAndView();
	   if(result.hasErrors()){
		   
		   model.setViewName("entryForm");
		   return model;
		   
	   }
		try {
			Emp traineeResponse =	services.addEmpeDetails(emp);
			 model.setViewName("successInsert");
			model.addObject("emp", traineeResponse);
			return model;
		} catch (EmpExceptions e) {
			model.setViewName("error");
			model.addObject("errMsg", "Insertion failed:"+e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/deleteData.do")
	public ModelAndView deleteData(@RequestParam("id") int empNo){
		 ModelAndView model=null;
		
		try {
			boolean emp = services.deleteEmp(empNo);
			
			 model = new ModelAndView("successDelete");
			
		} catch (EmpExceptions e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		
		return model;
		
	}
	
}
