package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;


@Repository("empDao")
public class EmpDaoImpl implements EmpDao {

	@PersistenceContext
	private EntityManager manager;
	
	
	//@Resource(name="entityMFactory")
  /*  public void setEntityMFactory(EntityManagerFactory factory){
    	
    	this.factory=factory;
    	
    }*/

	@Override
	public Emp getEmpDetails(int empId) throws EmpExceptions {
	
		
		//EntityManager manager = factory.createEntityManager();
		Emp emp = manager.find(Emp.class, empId);
    
		return emp;
	}

	@Override
	public List<Emp>getAllEmp() throws EmpExceptions {
		
		//EntityManager manager = factory.createEntityManager();
		Query qry = manager.createNamedQuery("qryAllEmps", Emp.class);
		
		return qry.getResultList();
	}

	@Override
	public Emp addEmpeDetails(Emp emp) throws EmpExceptions {
		//EntityManager manager = factory.createEntityManager();
		try {
			//manager.getTransaction().begin();
			manager.persist(emp);
			//manager.getTransaction().commit();
		} catch (RollbackException e) {
			throw new EmpExceptions("Record not committed",e);
		}
	
		return emp;
	}



	@Override
	public Emp updateEmp(Emp emp) throws EmpExceptions {
		
		//EntityManager manager = factory.createEntityManager();
		try {
			//manager.getTransaction().begin();
			manager.merge(emp);
			//manager.getTransaction().commit();
		} catch (RollbackException e) {
			throw new EmpExceptions("Failed:Name Updation",e);
		}
		
		return emp;
	}

	@Override
	public boolean deleteEmp(int empNo) throws EmpExceptions {
		try {
			Emp emp = this.getEmpDetails(empNo);
			manager.remove(emp);
		} catch (RollbackException e) {
			throw new EmpExceptions("Failed:deletion",e);
		}
		
		return true;
	}



}
